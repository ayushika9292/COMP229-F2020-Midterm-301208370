//books.js
//Name : Ayushika Mahajan
//Student ID : 301208370
//Web app name : MY FAVOURITE BOOKS

// modules required for routing
let express = require('express');
let router = express.Router();
let mongoose = require('mongoose');

// define the book model
let book = require('../models/books');

/* GET books List page. READ */
router.get('/', (req, res, next) => {
  // find all books in the books collection
  book.find( (err, books) => {
    if (err) {
      return console.error(err);
    }
    else {
      res.render('books/index', {
        title: 'Books',
        books: books
      });
    }
  });

});

//  GET the Book Details page in order to add a new Book --- DONE
router.get('/add', (req, res, next) => {

    res.render('books/details', {
      title: 'Enter details of book to Add',
      books: '',
      action: '/books/add'
    });

});

// POST process the Book Details page and create a new Book - CREATE
router.post('/add', (req, res, next) => {

  let newBookData = req.body;

  const newBook = {
    Title: newBookData.title,
    Description: newBookData.description,
    Price: parseInt(newBookData.price),
    Author: newBookData.author,
    Genre: newBookData.genre
  }
  // Creates the book on MongoDB -- DONE
  book.create(newBook, function(error, result) {
    if (error) {
      res.send(error);
    } else {
      res.redirect('/books');
    }
  });

});

// GET the Book Details page in order to edit an existing Book -- DONE
router.get('/:id', (req, res, next) => {

  book.findById( req.params.id , (err, book) => {
    if (err) {
      return console.error(err);
    }
    else {
      res.render('books/details', {
        title: 'Update details of book to edit',
        books: book,
        action: ''
      });
    }
  });
});

// POST - process the information passed from the details form and update the document -- DONE
router.post('/:id', (req, res, next) => {

  let singleBook = req.body;


  const updatedData = {
    Title: singleBook.title,
    Description: singleBook.description,
    Price: parseInt(singleBook.price),
    Author: singleBook.author,
    Genre: singleBook.genre
  }

  book.update( {_id: req.params.id} , updatedData, {upsert: true}, (error, result) => {
    if (error) {
      return console.error(error);
    }
    else {
      res.redirect('/books');
    }
  });

});

// GET - process the delete by user id  -- DONE
router.get('/delete/:id', (req, res, next) => {

  book.remove( {_id: req.params.id} , (error) => {
    if (error) {
      return console.error(error);
    }
    else {
      res.redirect('/books');
    }
  });
});


module.exports = router;
