//db.js
//Name : Ayushika Mahajan
//Student ID : 301208370
//Web app name : MY FAVOURITE BOOKS


module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb://localhost/books229"
};
